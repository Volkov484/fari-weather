# fari-weather
Proyecto para crear un widget para conectar la estacion meteorologica del colegio la farigola del clot.
Se trata de una estacion metorologica que trabaja con Weather Underground, busque algun plugin que funcionase para poder mostrar los valores en tiempo real de la estacion meteorologica del colegio, al no encontrar ninguno para wordpress decidi crear uno.
Este es mi primer proyecto tanto en PHP como en wordpress, he intentado seguir las convenciones de nombres y los estilos de programacion, pero queda evidente que es un trabajo amateur.
